<?php

$connect = mysqli_connect("localhost", "root", "", "project_inv");
$output = '';
if (isset($_POST["query"])) {
    $search = mysqli_real_escape_string($connect, $_POST["query"]);
    $query = "
 SELECT i.invoice_no,d.product_name,d.qty,i.customer_name,i.order_date,i.due,i.status,i.created_by FROM invoice i, invoice_details d  WHERE d.onvoice_no = i.invoice_no AND customer_name LIKE '%" . $search . "%'

 ";
} else {
    $query = "
  SELECT i.invoice_no,d.product_name,d.qty,i.customer_name,i.order_date,i.due,i.status,i.created_by FROM invoice i, invoice_details d  WHERE d.invoice_no = i.invoice_no
 ";
}
$result = mysqli_query($connect, $query);
if (mysqli_num_rows($result) > 0) {

    ?>
    <div class="table-responsive">
        <table class="table table-hover table bordered table-dark">
            <thead class="thead-light">
                <tr>
                    <th>NO:</th>
                    <th>Invoice No</th>
                    <th>Created_by</th>
                    <th>Customer Name</th>
                    <th>Order Date</th>
                    <th>Due</th>
                    <th>Status</th>

                    <!-- Actions section -->
                    <th></th>
                    <th>Actions</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <?php
                $n = 0;
                while ($row = mysqli_fetch_array($result)) {


                    ?>
                <tbody>
                    <tr>
                        <td><?php echo ++$n; ?></td>
                        <td><?php echo $row["invoice_no"]; ?></td>
                        <td><?php echo $row["created_by"]; ?></td>
                        <td><?php echo $row["customer_name"]; ?></td>
                        <td><?php echo $row["order_date"]; ?></td>
                        <td><?php echo $row["due"]; ?></td>
                        <td><?php echo $row["status"]; ?></td>
                        <td><button>test</button></td>
                        <td><button>test</button></td>
                        <td><button>test</button></td>
                        <td><button>test</button></td>
                    </tr>

                       

            <?php

                }
                echo $output;
            } else {
                echo 'Data Not Found';
            }
            ?>
        </table>
    </div>