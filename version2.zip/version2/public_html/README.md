# Inventory-Management-System-with-Html-Bootstrap-jQuery and-PHP-

In the software , First there is a registration system for the admin.After registration admin can login to the system,If the email and password is correct. after login admin will  get a dashboard. In the dashboard there are options like , Manage Category , Manage Brands and manage Products.Admin can add,edit delete and view the category , brand and products.Admin can make orders.There is a option in the dashboard for making new oders,it will provide order form to make a order.Admin can also see the total profit and can see the top selling product.



#To work with create  a new folder name >> inventory_project2 inside your htdocs folder in xampp , inside this inventory_project2 folder create another folder name >> public_html inside this folder copy all the files and export the database in the mysql and run the software..

#Tools

This  system is  built with PHP language. In the fornt-end I have used HTML and Bootstrap. In the back-end I have used PHP as a server site language. Also for retrive data from the HTML pages i have used JQUERY.This software is free anyone can work on this and can take it. The code is documented properly for understanding.
