$(document).ready(function () {
    var DOMAIN = "http://localhost/inventory_project2/public_html";

    addNewRow();

    $("#add").click(function () {
        addNewRow();
    })

    function addNewRow() {
        $.ajax({
            url: DOMAIN + "/includes/process.php",
            method: "POST",
            data: { getNewOrderItem: 1 },
            success: function (data) {
                $("#invoice_item").append(data);
                var n = 0;
                $(".number").each(function () {
                    $(this).html(++n);
                })
            }
        })
    }



    function addNewRow() {
        $.ajax({
            url: DOMAIN + "/includes/process.php",
            method: "POST",
            data: { getNewOrderItem: 1 },
            success: function (data) {
                $("#invoice_item_order").append(data);
                var n = 0;
                $(".number").each(function () {
                    $(this).html(++n);
                })
            }
        })
    }



    $("#remove").click(function()
    {
        $("#invoice_item").children("tr:last").remove();
        // calculate(0,0);
    })

    //order
    $("#remove").click(function()
    {
        $("#invoice_item_order").children("tr:last").remove();
        // calculate(0,0);
    })


    $("#invoice_item").delegate(".pid","change",function(){
        var pid  = $(this).val();
        var tr  = $(this).parent().parent();
        $(".overlay").show();
        $.ajax({
            url : DOMAIN+"/includes/process.php",
            method : "POST",
            dataType : "json",
            data : {getPriceAndQty:1, id:pid},
            success : function (data) {
                
                tr.find(".tqty").val(data["product_stock"]);
                
                tr.find(".pro_name").val(data["product_name"]);
                tr.find(".qty").val(1);
                
                
            }

        })

    })

    //order


    $("#invoice_item_order").delegate(".pid","change",function(){
        var pid  = $(this).val();
        var tr  = $(this).parent().parent();
        $(".overlay").show();
        $.ajax({
            url : DOMAIN+"/includes/process.php",
            method : "POST",
            dataType : "json",
            data : {getPriceAndQty:1, id:pid},
            success : function (data) {
                
                tr.find(".tqty").val(data["product_stock"]);
                
                tr.find(".pro_name").val(data["product_name"]);
                tr.find(".qty").val(1);
                
                
            }

        })

    })

    $("#invoice_item").delegate(".qty","keyup",function(){
        var qty = $(this);
        var tr = $(this).parent().parent();
        
        if(isNaN(qty.val())){
            alert("Please Enter a valid quantity");
            qty.val(1);

        }
        else{
           if((qty.val() -0) > (tr.find(".tqty").val()) -0){
               alert("Stock overflow");
               qty.val(1);

           }
           
        
        }
    })

 
    // rental taking 

    $("#rental_form").click(function () {
        var invoice = $("#get_rental_data").serialize();

        if ($("#cust_name").val() === "")
               {
            alert("Please Enter Customer Name");
               }
               else{
               
            $.ajax({
                url: DOMAIN + "/includes/process.php",
                method: "POST",
                data: $("#get_rental_data").serialize(),
                success: function (data) {
                    
                 
                    $("#get_rental_data").trigger("reset");
                   
                      
                          if (data.trim() == "Order failed due to Insufficient stock") {
                              alert("Order Failed due to Insufficient Stock");
                              window.location.href = DOMAIN + "/new_rental.php";
                          }
                      else{
                        if (confirm("Confrim Rental?")) {
                            const redirectUrl = DOMAIN + "/success_rental.php";  
                            console.log("Redirecting to:", redirectUrl);
                            window.location.href = redirectUrl;
                        }
                        
                         
                    }
                }
            })
       }
    })




    // order taking 

    $("#order_form").click(function () {
        var invoice = $("#get_order_data").serialize();

        if ($("#cust_name").val() === "")
               {
            alert("Please Enter Customer Name");
               }
               else{
               
            $.ajax({
                url: DOMAIN + "/includes/process.php",
                method: "POST",
                data: $("#get_order_data").serialize(),
                success: function (data) {
                    
                 
                    $("#get_order_data").trigger("reset");
                   
                      
                          if (data.trim() == "Order failed due to Insufficient stock") {
                              alert("Order Failed due to Insufficient Stock");
                              window.location.href = DOMAIN + "/new_order.php";
                          }
                      else{
                        if (confirm("Confrim Rental?")) {
                            const redirectUrl = DOMAIN + "/success_order.php";  
                            console.log("Redirecting to:", redirectUrl);
                            window.location.href = redirectUrl;
                        }
                        
                         
                    }
                }
            })
       }
    })

});