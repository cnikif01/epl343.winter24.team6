-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 07:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_inv`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `bid` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`bid`, `brand_name`, `status`) VALUES
(1, 'samsung', '1'),
(5, 'xaomi', '1'),
(8, 'Nissan', '1'),
(10, 'Huawei', '1'),
(19, 'DASSAULT', '1'),
(20, 'HONDA', '1'),
(22, 'Fighter Jets', '1'),
(25, 'Euro Fighter', '1'),
(26, 'Suzuki', '1'),
(27, 'MI', '1'),
(28, 'BlackBerry', '1'),
(29, 'RFL', '1'),
(30, 'laptop', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `parent_cat` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `parent_cat`, `category_name`, `status`) VALUES
(5, 1, 'Phone', '1'),
(6, 5, 'Apple', '1'),
(14, 0, 'Plane', '1'),
(19, 0, 'Bike', '1'),
(20, 1, 'Miter', '1'),
(21, 0, 'Plastic', '1'),
(24, 0, 'helmet', '1');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_no` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `order_date` date NOT NULL,
  `due` datetime DEFAULT NULL,
  `status` text NOT NULL DEFAULT '\'pending approval\'',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_no`, `customer_name`, `Phone`, `created_by`, `order_date`, `due`, `status`, `created_at`) VALUES
(53, 'Nishad', '', '0', '2019-11-28', NULL, 'in progress', '2024-10-27 13:22:47'),
(54, 'check_profit', '', '0', '2019-11-29', NULL, 'in progress', '2024-10-27 13:22:47'),
(55, 'test t profit', '', '0', '2019-11-29', NULL, 'in progress', '2024-10-27 13:22:47'),
(56, 'Alvi2', '', '0', '2019-11-29', NULL, 'in progress', '2024-10-27 13:22:47'),
(57, 'Nishad', '', '0', '2019-11-29', NULL, 'in progress', '2024-10-27 13:22:47'),
(59, 'check', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(60, 'check', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(63, 'check_print', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(64, 'check_print', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(65, 'final_print', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(66, 'check_print_10', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(67, 'Abir', '', '0', '2019-12-01', NULL, 'in progress', '2024-10-27 13:22:47'),
(68, 'Faruque', '', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(69, 'Abir2', '', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(70, 'Kawsar', '', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(72, 'Nishad', '01728897264', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(73, 'check_number', '01728897264', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(74, 'AKib', '01728897255', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(75, 'gt', '01728845454', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(84, 'check33', '01728845454', '0', '2019-12-02', NULL, 'in progress', '2024-10-27 13:22:47'),
(85, 'kamal', '01728845454', '0', '2019-12-03', NULL, 'in progress', '2024-10-27 13:22:47'),
(86, 'Alvi ', '01728845454', '0', '2019-12-04', NULL, 'in progress', '2024-10-27 13:22:47'),
(87, 'Abir', '01876588', '0', '2019-12-04', NULL, 'in progress', '2024-10-27 13:22:47'),
(88, 'Bohemain', '01728845454', '0', '2019-12-15', NULL, 'in progress', '2024-10-27 13:22:47'),
(89, 'jfhf', '999999', '0', '2024-10-16', NULL, 'in progress', '2024-10-27 13:22:47'),
(90, 'test3', '55555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(91, 'test3', '555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(92, 'test3', '5555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(93, 'test3', '555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(94, 'test', '55555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(95, 'test', '5555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(96, 'test1', '5555555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(97, 'test3', '55555', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(98, 'test tr', '123456789', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(99, 'test tr 2', '123456789', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(100, 'test tr 3', '123456789', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(101, 'test 4 ', '655415151', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(102, 'test5', '65654155', '0', '0000-00-00', NULL, 'in progress', '2024-10-27 13:22:47'),
(103, 'test final ', '154654151', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(104, 'test sucess', '655515', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(105, 'test10', '654154154154', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(106, 'test successs', '85854545', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(107, 'test success', '52441541541', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(108, 'dfsdfsd', '564545', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(109, 'dvgf', '52572', '0', '2024-10-26', NULL, 'in progress', '2024-10-27 13:22:47'),
(110, 'test ', '561515', 'aimilios', '2024-10-27', NULL, 'in progress', '2024-10-27 13:22:47'),
(111, 'test due', '5685485485', 'aimilios', '2024-10-27', '2024-10-30 20:25:00', 'in progress', '2024-10-27 13:22:47'),
(112, 'yyt', '7678678678', 'test', '2024-10-30', '2024-11-06 21:29:00', '\'pending approval\'', '2024-10-30 15:25:09'),
(113, 'test no qty ', '7777878787', 'test', '2024-10-30', '2024-11-06 22:31:00', '\'pending approval\'', '2024-10-30 15:26:10');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`id`, `invoice_no`, `product_name`, `qty`) VALUES
(1, 53, 'Typhoon', 1),
(2, 54, 'Note Pro', 1),
(3, 54, 'Rafale', 1),
(4, 55, 'Samsung Galaxy 10', 9),
(5, 56, 'Rafale', 1),
(6, 57, 'Note Pro', 1),
(7, 57, 'Note Pro', 1),
(8, 59, 'Samsung Galaxy 10', 1),
(9, 63, 'Note Pro', 1),
(10, 64, 'Typhoon', 1),
(11, 65, 'Samsung Galaxy 10', 1),
(12, 66, 'Samsung Galaxy 10', 1),
(13, 67, 'Note Pro', 1),
(14, 68, 'Gixer', 1),
(15, 69, 'Gixer', 1),
(16, 69, 'Samsung Galaxy 10', 1),
(17, 70, 'GT-500', 1),
(19, 72, 'GT-500', 1),
(20, 73, 'GT-500', 1),
(21, 74, 'F-16', 1),
(22, 75, 'GT-500', 1),
(23, 75, 'GT-500', 1),
(24, 84, 'GT-500', 1),
(25, 85, 'Samsung Galaxy 10', 2),
(26, 86, 'Samsung Galaxy 10', 1),
(27, 87, 'Samsung Galaxy 10', 3),
(28, 88, 'GT-500', 1),
(29, 89, 'Typhoon', 1),
(30, 89, 'Samsung Galaxy 10', 1),
(31, 96, '', 0),
(32, 97, '', 0),
(33, 97, NULL, 1),
(34, 98, NULL, 1),
(35, 99, NULL, 5),
(36, 100, NULL, 5),
(37, 101, NULL, 1),
(38, 102, 'Gixer', 1),
(39, 103, 'Gixer', 1),
(40, 104, 'F-16', 1),
(41, 105, 'GT-500', 1),
(42, 106, 'GT-500', 1),
(43, 107, 'GT-500', 4),
(44, 108, 'GT-500', 5),
(45, 109, 'GT-500', 5),
(46, 110, 'Gixer', 1),
(47, 111, 'Chair', 1),
(48, 112, 'F-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_stock` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `p_status` enum('1','0') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `cid`, `bid`, `product_name`, `product_stock`, `added_date`, `p_status`) VALUES
(3, 5, 5, 'Note Pro', 0, '2019-12-03', '1'),
(4, 5, 1, 'Samsung Galaxy 10', 0, '2019-12-01', '1'),
(5, 14, 19, 'Rafale', 8, '2019-11-28', '1'),
(7, 5, 1, 'GT-500', 977, '2019-11-29', '1'),
(8, 19, 26, 'Gixer', 0, '2019-12-02', '1'),
(9, 14, 8, 'F-16', 2, '2019-12-02', '1'),
(10, 21, 29, 'Chair', 9, '2019-12-02', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `usertype` enum('Admin','Other') NOT NULL,
  `register_date` date NOT NULL,
  `last_login` datetime NOT NULL,
  `notes` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `requested_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `usertype`, `register_date`, `last_login`, `notes`, `reset_token`, `requested_at`) VALUES
(8, 'Kh Nishad', 'kkhnishad@gmail.com', '$2y$08$eE.lphrTj1FyiKbQvzkUsOEmYLQna7a60eIQ1DlQISEAqlDMdY/US', 'Admin', '2019-10-26', '2019-12-15 06:12:02', '', NULL, NULL),
(21, 'faruque', 'faruque@gmail.com', '$2y$08$tKwaNJWGOV1ltyPUvJCibO/Li/iNRr2aJEYwe8UYuniZzfVCtDISW', 'Admin', '2019-12-02', '2019-12-02 08:12:28', '', NULL, NULL),
(34, 'Abdus Sattar', 'abdsattar@gmail.com', '$2y$08$Zt4u6rWdeWEfnW8uJALSLeQa531KrkM6/FW87OtRmujatSYMsvPwy', 'Admin', '2019-12-03', '2019-12-03 00:00:00', '', NULL, NULL),
(39, 'toma', 'momtarintoma@gmail.com', '$2y$08$6LfAQk5r/tKMWxXContHZ.BnCqMUh0vIjUx.CcKXX6P/uTKioPPia', 'Admin', '2019-12-03', '2019-12-03 11:12:43', '', NULL, NULL),
(45, 'toma', 'toma@gmail.com', '$2y$08$OvXbkMhi0jgfKq2QFlTrHeLJPkzbc09.wFlhWli/AvSeRGMlK6NRq', 'Admin', '2019-12-03', '2019-12-03 06:12:22', '', NULL, NULL),
(46, 'Adnan', 'adnan@gmail.com', '$2y$08$6sIcpmh7AbvPwsMPorRTo.JEURDqsa1iXcIyik20lh7SYNRuEpnfS', 'Admin', '2019-12-04', '2019-12-04 00:00:00', '', NULL, NULL),
(47, 'toma', 'toma1@gmail.com', '$2y$08$3kvfJ2Dl.s7pi4rfLOtUD.1fsPu78m.vt1g6f1mZ6q52cFpQO81/O', 'Admin', '2019-12-04', '2019-12-04 06:12:19', '', NULL, NULL),
(48, 'mumu', 'mumu@gmail.com', '$2y$08$6uhFXFrUDDLuNOAUR6qud.m8d1qxCVobsltg/tGs8O/Cgk4XYoUwO', 'Admin', '2019-12-04', '2019-12-04 09:12:45', '', NULL, NULL),
(49, 'test', 'test@test.com', '$2y$08$HDJ8Og8oTGp7ZNUS7CcZWObREU0Lm2eVGlYJUIDiq1xr7AHE106VS', 'Admin', '2024-10-16', '2024-10-16 03:10:19', '', NULL, NULL),
(50, 'aimilios', 'aimilios.ael@outlook.com', '$2y$08$bgJTXj49luWZimqcOPwWcudNryC0/dmcMmjXa.Hw5OrY2/9gMxjHK', 'Admin', '2024-10-20', '2024-11-20 07:11:33', '', NULL, NULL),
(56, 'test', 'test1@test.com', '$2y$08$LdpgbpFXqJQzw1IZzd54uOB3n/VeuqUjqVcEx9NGvChGZFEJ2xna2', 'Other', '2024-10-25', '2024-11-14 02:11:40', '', NULL, NULL),
(57, 'styliana', 'styliana@email.com', '$2y$08$F8tLC4KmlIVv4Rqw4d6w/eKiDCcqVe5u7mtW.49vY4zciNFgL20ni', 'Other', '2024-11-20', '2024-11-20 00:00:00', '', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `brand_name` (`brand_name`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `category_name` (`category_name`) USING BTREE;

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_no`);

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_no` (`invoice_no`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `product_name` (`product_name`),
  ADD KEY `cid` (`cid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `invoice_details`
--
ALTER TABLE `invoice_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD CONSTRAINT `invoice_details_ibfk_1` FOREIGN KEY (`invoice_no`) REFERENCES `invoice` (`invoice_no`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `categories` (`cid`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `brands` (`bid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
