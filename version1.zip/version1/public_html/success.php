
<?php

$redirectUrl = isset($_SESSION['role']) && $_SESSION['role'] == "Other" ? "user_dashboard.php" : "dashboard.php";
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Success</title>
    <style>
        /* Basic reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #4CAF50, #8BC34A);
            color: #fff;
            text-align: center;
        }

        .container {
            max-width: 400px;
            padding: 2rem;
            background-color: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .container h1 {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #ffffff;
        }

        .container p {
            font-size: 1rem;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .countdown {
            font-weight: bold;
            font-size: 1.2rem;
            color: #FFC107;
        }

        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            margin-top: 1rem;
            color: #4CAF50;
            background-color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #F1F1F1;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Rental Successful!</h1>
    <p>Your rental has been processed successfully. You will be redirected shortly.</p>
    <p class="countdown">Redirecting in <span id="countdown">5</span> seconds...</p>
    <?php
    if(isset($_SESSION['role']) && $_SESSION['role']=="Other"){
    ?>
        <a href="user_dashboard.php" class="btn">Go to Dashboard Now</a>
    <?php
    }else{
    ?>
        <a href="dashboard.php" class="btn">Go to Dashboard Now</a>
    <?php
    }

    ?>
    
</div>

<script>
    let countdown = document.getElementById("countdown");
    let seconds = 5;
    const redirectUrl = "<?php echo $redirectUrl; ?>";

    // Update countdown every second
    const countdownTimer = setInterval(() => {
        seconds--;
        countdown.textContent = seconds;
        
        if (seconds <= 0) {
            clearInterval(countdownTimer);
            // Redirect to the dashboard after countdown reaches 0
            window.location.href = redirectUrl;
        }
    }, 1000);
</script>

</body>
</html>
