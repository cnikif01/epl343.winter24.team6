<?php
$redirectUrl = isset($_SESSION['role']) && $_SESSION['role'] == "Other" ? "user_dashboard.php" : "dashboard.php";


include_once("./database/constants.php");
if (!isset($_SESSION["userid"])) {
    header("location:" . DOMAIN . "/");
}



?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Inventory Management System</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/97c02f89cd.js"></script>
    <script type="text/javascript" src="./js/order.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script>
            // Initialize Flatpickr with European date format
            flatpickr("#due", {
                enableTime: true,
                dateFormat: "d-m-Y H:i", // European format: DD-MM-YYYY HH:MM
                time_24hr: true          // Use 24-hour time format
            });
</script>

</head>

<body>
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <!-- Navbar -->
   
	<!-- Navbar Start -->
	<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed py-2">
		<a class="navbar-brand text-primary text-uppercase font-weight-bold" href="#">
			<h3>Semesco</h3>
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link text-light text-uppercase font-weight-bold px-3" href="#"  onclick="window.location.href = '<?php echo $redirectUrl; ?>';"> <i class="fas fa-home text-primary"></i> Home <span class="sr-only">(current)</span></a>
				</li>
				<?php if(isset($_SESSION["userid"])) { ?>
					<li class="nav-item">
						<a class="nav-link text-light text-uppercase font-weight-bold px-3" href="logout.php" > <i class="fas fa-sign-out-alt text-danger"></i> Logout</a>
					</li>
				<?php } ?>
			</ul>
		</div>
	</nav>
	<!-- Navbar End -->
    <br>

    <div class="container">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="card" style="box-shadow:0 0 25px 0 lightgrey;">
                    <div class="card-header text-center">
                        <h4>New Rental</h4>
                    </div>
                    <div class="card-body bg-dark text-white">
                        <form id="get_order_data" onsubmit="return false">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label" align="right">Order Date</label>
                                <div class="col-sm-6">
                                    <input type="text" id="order_date" name="order_date" readonly class="form-control form-control-sm" value="<?php echo date("d / m / y"); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label" align="right">Created by</label>
                                <div class="col-sm-6">
                                    <input type="text" id="creator_name" name="creator_name" readonly class="form-control form-control-sm" value="<?php echo $_SESSION["username"]; ?>" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label" align="right">Employee Name*</label>
                                <div class="col-sm-6">
                                    <input type="text" id="cust_name" name="cust_name" class="form-control form-control-sm" placeholder="Enter Employee Name" required />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label" align="right">Phone</label>
                                <div class="col-sm-6">
                                    <input type="text" id="phone" name="phone" class="form-control form-control-sm" placeholder="Enter Phone Number" required />
                                </div>
                            </div>


                            <div class="card  bg-dark" style="box-shadow:0 0 5px 0 lightgrey;">
                                <div class="card-body">
                                    <div class="text-center">
                                        <h3 class="">New Rental List</h3>
                                    </div>
                                    <br>

                                    <table style="margin:auto;" style="width:800px;">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th style="text-align:center;">Item Name</th>
                                                <th style="text-align:center;">Total Quantity</th>
                                                <th style="text-align:center;">Quantity</th>
                                                
                                                <!-- <th style="text-align:center;">Stock Price</th> -->
                                                

                                            </tr>
                                        </thead>
                                        <tbody id="invoice_item"></tbody>
                                            
                                          
                                        


                                    </table>
                                    <!--Table Ends-->
                                    <center style="padding:10px;">
                                        <button id="add" style="width:150px;" class="btn btn-success">Add</button>
                                        <button id="remove" style="width:150px;" class="btn btn-danger">Remove</button>
                                    </center>
                                </div>
                                <!--Crad Body Ends-->
                            </div> <!-- Order List Crad Ends-->

                            <p></p>
                            
                            <div class="form-group row">
                                <label for="due" class="col-sm-3 col-form-label" align="right">Due</label>
                                <div class="col-sm-6">
                                    <input type="datetime-local" name="due" class="form-control form-control-sm" id="due" required />
                                </div>
                            </div>


                          

                            <center>
                                <input type="submit" id="order_form" style="width:150px;" class="btn btn-success" value="Order">
                                <input type="submit" id="print_invoice" style="width:150px;" class="btn btn-success d-none" value="Print Invoice">
                            </center>


                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>



</body>

</html>